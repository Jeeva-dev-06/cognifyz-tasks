<script>
    document.querySelector('.btn-success').addEventListener('click', function() {
        alert('Thank you for showing interest! We will contact you soon.');
    });
</script>

// Your existing fetchquote function
function fetchquote() {
    // Show a loading message (optional, but good UX)
    document.getElementById('quote').innerText = "Loading quote...";

    fetch('https://api.quotable.io/random')
        .then(response => {
            if (!response.ok) { // Check if the response status is OK (e.g., 200)
                throw new Error(`HTTP error! Status: ${response.status}`);
            }
            return response.json();
        })
        .then(data => {
            // Check if data has the expected properties
            if (data && data.content && data.author) {
                 document.getElementById('quote').innerText = `"${data.content}" — ${data.author}`;
            } else {
                // Handle cases where API returns unexpected data
                 document.getElementById('quote').innerText = "Received incomplete data from API.";
                 console.warn("API response missing content or author:", data);
            }
        })
        .catch((error) => { // Catch network errors AND errors thrown above
            console.error('Fetch Error:', error); // Log the actual error
            document.getElementById('quote').innerText = "Failed to fetch quote. Please try again later.";
        });
}

// --- ADD THIS PART ---
// Get the button element by its ID
const quoteButton = document.getElementById('new-quote-btn');

// Add an event listener that calls fetchquote when the button is clicked
if (quoteButton) { // Check if the button was found
   quoteButton.addEventListener('click', fetchquote);
} else {
   console.error("Could not find the button with id 'new-quote-btn'");
}

// --- Optional: Load a quote when the page first loads ---
// document.addEventListener('DOMContentLoaded', fetchquote); // Uncomment this line if you want a quote on page load
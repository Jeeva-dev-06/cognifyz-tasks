function validateForm() {
    const name = document.getElementById('name').value.trim();
    const email = document.getElementById('email').value.trim();
    const feedback = document.getElementById('feedback').value.trim();
    const message = document.getElementById('formMessage');

    if (!name || !email || !feedback) {
        message.innerText = "All fields are required!";
        message.style.color = "red";
        return false;
    } else {
        message.innerText = "Form submitted successfully!";
        message.style.color = "green";
        return false; // prevent reload for demo
    }
}

function changeBackground() {
    const colors = ["#fce4ec", "#e3f2fd", "#e8f5e9", "#fff3e0", "#ede7f6"];
    document.body.style.backgroundColor = colors[Math.floor(Math.random() * colors.length)];
}
